# PLC Control Tools & Agent Package

Lightweight, browser-based, AI-assisted tools for PLC code auditing, symbol cross-referencing, and safety compliance.

## Package Contents
- `index.html`: Standard PLC Logic AI Inspector.
- `plc_cross_referencer_poc.html`: Tag & Symbol Cross-Referencing Proof-of-Concept.
- `plc_agent_dashboard.html`: Autonomous PLC Safety & Compliance Agent with live pipeline execution.

## Model Configuration
Pre-configured to use the `gemini-3.8-flash` endpoint via REST API calls.

## How to Run
Open any `.html` file directly in Google Chrome or Microsoft Edge and paste your Gemini API key in the header input.
