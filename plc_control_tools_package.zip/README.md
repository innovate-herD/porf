# PLC Logic AI Inspector

An interactive web dashboard for Control Systems and Automation Engineers to perform static analysis, safety interlock checks, scan-cycle race condition detection, and variable symbol table cross-referencing on PLC routines.

## Included Files
- `index.html`: Main application entry point (Standalone HTML/JS).
- `README.md`: Setup and usage instructions.

## How to Run
1. Unzip `plc_logic_inspector_package.zip` onto your Windows machine.
2. Double-click `index.html` to open it in **Google Chrome** or **Microsoft Edge**.
3. Paste your **Gemini API Key** into the input field at the top right of the dashboard.
4. Select your target PLC language (Structured Text, Siemens SCL, Rockwell Studio 5000 / L5X, or Instruction List).
5. Paste your routine logic and symbol table, then click **Analyze Logic**.
